import ch0926.Account;

public class AccountTest {
    public static void main(String[] args) {
        Account a = new Account();
        Account b = new Account();
        a.transfer("123-45",10000);
        b.GetMoney("567-89",10000);

        }
    }
